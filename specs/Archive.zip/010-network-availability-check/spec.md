# Feature Specification: Network Availability Drafting

> **Feature number:** 010
> **Status:** Draft
> **Author:** Codex
> **Date:** 2026-06-19
> **Work item:** US-010

## Status history

| Date | Status | Author | Notes |
| --- | --- | --- | --- |
| 2026-06-19 | Draft | Codex | Initial spec created from `plan/us_010.md`, `plan/functionality.md`, current SDD workflow, and related recording-flow context |
| 2026-06-19 | Draft | Codex | Revised scope so missing network does not block audio recording and instead saves the captured audio as a draft |
| 2026-06-19 | Draft | Codex | Incorporated user clarifications for unknown connectivity, status auto-clear, and draft-save failure feedback |

---

## Overview

The current app records audio first, then needs network connectivity for cloud
transcription and cleanup. Missing connectivity should not prevent the user
from speaking or cause their captured audio to be discarded. Instead, the app
should let recording complete and preserve the audio as a retryable draft when
cloud processing cannot be attempted because the device is offline.

This feature adds a network availability decision before cloud transcription
and cleanup are attempted. If network is unavailable at that point, the app
saves the captured audio as a draft and clearly tells the user that the entry
was saved for later processing.

> **Reminder:** This spec must be **purely functional and technology-agnostic**.
> Describe the problem and requirements, not the solution. Technology choices
> belong in `plan.md`.

## User stories

- As a user, I want to record audio even when I currently have no connection so
  that my diary capture is not blocked by temporary connectivity.
- As a user, I want the app to save my offline recording as a draft so that it
  can be transcribed and cleaned up later.
- As a user, I want clear feedback when an entry is saved as a draft because
  there is no connection so that I know my recording was not lost.

## Acceptance criteria

- [ ] A user can start audio recording when the device has no usable network
      connectivity, subject to existing microphone permission and recording
      eligibility rules.
- [ ] While recording with no usable network connectivity, the app enters and
      leaves the active recording state according to the existing recording
      controls.
- [ ] After a valid recording is stopped, the app checks whether cloud
      transcription and cleanup can reasonably be attempted.
- [ ] If the post-recording availability check reports usable connectivity,
      the recording flow proceeds according to the existing cloud processing
      behavior.
- [ ] If the post-recording availability check reports no usable connectivity,
      the app does not attempt cloud transcription or cleanup for that
      recording immediately.
- [ ] If the post-recording availability check reports no usable connectivity,
      the captured audio is saved as a retryable audio draft.
- [ ] If the post-recording availability check reports no usable connectivity,
      the app does not save a completed diary entry for that attempt.
- [ ] If the post-recording availability check reports no usable connectivity,
      the main screen shows `no connection · saved as draft`.
- [ ] The no-connectivity draft status is shown after the recording stops and
      after the audio draft has been preserved.
- [ ] The no-connectivity draft status auto-clears using the existing
      status-clear timeout.
- [ ] After saving a no-connectivity audio draft, the app returns to a
      non-recording state where the user can start another recording.
- [ ] If the post-recording availability check reports unknown or
      indeterminate connectivity, the app treats the result like no usable
      connectivity and saves the captured audio as a retryable audio draft.
- [ ] If saving the no-connectivity audio draft fails, the app shows `error`
      and does not show a false draft-saved state.
- [ ] Connectivity failures, timeouts, backend unavailability, or upload
      failures that happen after cloud processing is attempted remain handled
      by the draft/retry flow.
- [ ] Existing microphone permission failures, too-short recording failures,
      transcription failures, and successful save behavior keep their existing
      user-facing semantics.
- [ ] The no-connectivity draft status exposes meaningful assistive technology
      feedback through the existing main-screen status mechanism.
- [ ] The behavior works correctly on both Android and iOS.

## API contract

This feature does not introduce or modify backend HTTP endpoints. It defines
the application-facing contract for a post-recording network availability
decision before cloud transcription and cleanup.

### Network availability inputs

The recording experience consumes:

- user action to start recording
- current network availability for attempting cloud upload
- current recording state
- existing permission and recording eligibility outcomes
- captured audio from a completed valid recording
- existing draft persistence availability

### Network availability outputs

The recording experience can request:

- continuation into the existing cloud transcription and cleanup flow when
  cloud upload can be attempted
- saving captured audio as a retryable draft when cloud upload cannot be
  attempted
- display of no-connection draft feedback after the draft is saved

Functional expectations:

- The network availability decision for this story must happen after a valid
  recording is captured and before cloud transcription or cleanup is attempted.
- Unknown or indeterminate connectivity must be treated as unavailable for this
  decision.
- Missing connectivity must preserve the captured audio as retryable draft
  data.
- Missing connectivity must not produce a completed diary entry before
  transcription and cleanup have succeeded.
- The availability decision is not a guarantee that upload will later succeed.
- Upload and backend failures after cloud processing is attempted remain
  separate errors and may update draft state according to the existing
  draft/retry rules.

## Data model changes

This story does not require a persistent database schema change.

Functional state used by this feature:

- current network availability result for cloud upload attempts
- current recording/error state
- captured audio from a valid stopped recording
- existing persisted entry and draft state

Functional expectations:

- A missing-network result creates a retryable audio draft for the captured
  recording.
- An unknown or indeterminate network result creates a retryable audio draft
  for the captured recording.
- A missing-network result does not create a completed diary entry.
- A failed draft-save result does not create a completed diary entry and must
  not report that a draft was saved.
- Existing entries are not modified by a missing-network result for a new
  recording.
- Existing drafts are not corrupted or replaced except through the normal draft
  persistence rules for saving the newly captured recording.

## Dependencies

- [ ] Existing main-screen recording action and status-line behavior
- [ ] Existing recording controller states for idle, active recording, saved,
      and error feedback
- [ ] Existing microphone permission gate and recording eligibility behavior
- [ ] Existing cloud transcription and cleanup flow
- [ ] Existing draft/retry behavior for network or backend failures after
      recording capture
- [ ] Existing audio draft persistence and retry behavior
- [ ] Platform ability to determine whether cloud upload can reasonably be
      attempted

## UX / design references

- `plan/us_010.md`
- `plan/functionality.md` error state for network failures saved as drafts

Functional UX notes:

- The no-connectivity status text must be `no connection · saved as draft`.
- The status should use the existing main-screen error/status presentation.
- The status must make clear that the recording was preserved as a draft.
- The no-connectivity draft status must auto-clear using the existing
  status-clear timeout.
- Draft-save failure feedback must use `error`.

## Non-functional requirements

- **Performance:** The availability check must be fast enough that the
  transition from stopped recording into processing, draft-saving, or feedback
  still feels responsive.
- **Security:** The feature must not send audio, transcripts, or other diary
  content while reporting a no-connectivity draft outcome.
- **Reliability:** No-connectivity, unavailable connectivity status, and
  ordinary recording retries must not crash the app, lose captured audio, start
  duplicate recording attempts, or leave the UI stuck in an active-recording
  state.
- **Scalability:** No new scalability requirements.
- **Observability:** No new analytics or telemetry behavior is required for
  this story.

## Test strategy

- Cover the post-recording cloud-processing decision logic with connectivity
  available and unavailable.
- Cover that unavailable connectivity after a valid recording creates an audio
  draft and does not create a completed entry.
- Cover that unknown or indeterminate connectivity after a valid recording
  creates an audio draft and does not create a completed entry.
- Cover that audio draft save failure shows `error` and does not show
  draft-saved feedback.
- Cover that recording can still start and stop while connectivity is
  unavailable.
- Cover main-screen status behavior for the no-connection draft outcome.
- Cover every in-scope user flow with `integration_test` unless an exception is
  requested and explicitly approved during planning.
- Verify the final implementation on an Android emulator and an iOS simulator
  unless an exception is requested and explicitly approved during planning.

## Out of scope

- Retrying failed uploads or cleanup work after a draft has been saved.
- Changing the draft/retry rules for post-start network, timeout, or backend
  failures.
- Changing microphone permission behavior.
- Changing quota, device registration, or backend API contracts.
- Adding analytics or telemetry for connectivity failures.
- Guaranteeing actual internet reachability beyond the availability
  signal.

## Open questions

None.
